// Declaração da classe Cliente sem package
public class Cliente {
    // Identificador único do cliente
    private int id;
    // Nome completo do cliente
    private String nome;
    // Email de contato do cliente
    private String email;
    // Endereço residencial ou comercial do cliente
    private String endereco;

    // Construtor padrão utilizando os setters para reaproveitar validações
    public Cliente(int id, String nome, String email, String endereco) {
        // Define o id com validação
        setId(id);
        // Define o nome com validação
        setNome(nome);
        // Define o email com validação
        setEmail(email);
        // Define o endereço com validação
        setEndereco(endereco);
    }

    // Retorna o id do cliente
    public int getId() {
        // Devolve o valor atual de id
        return id;
    }

    // Atualiza o id do cliente com validação
    public void setId(int id) {
        // Confere se o id é positivo
        if (id <= 0) {
            // Lança exceção para valores inválidos
            throw new IllegalArgumentException("Id deve ser maior que zero.");
        }
        // Armazena o id validado
        this.id = id;
    }

    // Retorna o nome do cliente
    public String getNome() {
        // Devolve o valor atual de nome
        return nome;
    }

    // Atualiza o nome do cliente com validação
    public void setNome(String nome) {
        // Verifica se o nome é nulo ou vazio
        if (nome == null || nome.trim().isEmpty()) {
            // Lança exceção quando o nome é inválido
            throw new IllegalArgumentException("Nome não pode ser vazio.");
        }
        // Guarda o nome já aparado
        this.nome = nome.trim();
    }

    // Retorna o email do cliente
    public String getEmail() {
        // Devolve o valor atual de email
        return email;
    }

    // Atualiza o email do cliente com validação
    public void setEmail(String email) {
        // Verifica se o email é nulo ou vazio
        if (email == null || email.trim().isEmpty()) {
            // Lança exceção quando o email é inválido
            throw new IllegalArgumentException("Email não pode ser vazio.");
        }
        // Verifica se contém arroba como validação mínima
        if (!email.contains("@")) {
            // Lança exceção quando o formato é inválido
            throw new IllegalArgumentException("Email deve conter '@'.");
        }
        // Guarda o email aparado
        this.email = email.trim();
    }

    // Retorna o endereço do cliente
    public String getEndereco() {
        // Devolve o valor atual de endereço
        return endereco;
    }

    // Atualiza o endereço do cliente com validação
    public void setEndereco(String endereco) {
        // Verifica se o endereço é nulo ou vazio
        if (endereco == null || endereco.trim().isEmpty()) {
            // Lança exceção quando o endereço é inválido
            throw new IllegalArgumentException("Endereço não pode ser vazio.");
        }
        // Guarda o endereço aparado
        this.endereco = endereco.trim();
    }

    // Representação textual completa do cliente
    @Override
    public String toString() {
        // Usa String.format para compor a saída legível
        return String.format("Cliente{id=%d, nome='%s', email='%s', endereco='%s'}",
                id, nome, email, endereco);
    }
}
