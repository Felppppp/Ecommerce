// Declaração da classe Produto sem package
public class Produto {
    // Identificador numérico do produto
    private int id;
    // Nome descritivo do produto
    private String nome;
    // Preço unitário do produto
    private double preco;
    // Quantidade disponível em estoque
    private int estoque;

    // Construtor padrão que delega para os setters para reaproveitar validações
    public Produto(int id, String nome, double preco, int estoque) {
        // Define o id usando a validação do setter
        setId(id);
        // Define o nome usando a validação do setter
        setNome(nome);
        // Define o preço usando a validação do setter
        setPreco(preco);
        // Define o estoque usando a validação do setter
        setEstoque(estoque);
    }

    // Retorna o identificador do produto
    public int getId() {
        // Devolve o valor atual de id
        return id;
    }

    // Define um novo identificador para o produto
    public void setId(int id) {
        // Garante que o id seja positivo
        if (id <= 0) {
            // Lança exceção se o id for inválido
            throw new IllegalArgumentException("Id deve ser maior que zero.");
        }
        // Atualiza o campo id com o valor válido
        this.id = id;
    }

    // Retorna o nome do produto
    public String getNome() {
        // Devolve o valor atual de nome
        return nome;
    }

    // Define um novo nome para o produto
    public void setNome(String nome) {
        // Garante que o nome não seja nulo ou vazio
        if (nome == null || nome.trim().isEmpty()) {
            // Lança exceção se o nome for inválido
            throw new IllegalArgumentException("Nome não pode ser vazio.");
        }
        // Atualiza o campo nome com o valor válido
        this.nome = nome.trim();
    }

    // Retorna o preço do produto
    public double getPreco() {
        // Devolve o valor atual de preço
        return preco;
    }

    // Define um novo preço para o produto
    public void setPreco(double preco) {
        // Garante que o preço seja maior que zero
        if (preco <= 0) {
            // Lança exceção se o preço for inválido
            throw new IllegalArgumentException("Preço deve ser maior que zero.");
        }
        // Atualiza o campo preço com o valor válido
        this.preco = preco;
    }

    // Retorna a quantidade em estoque
    public int getEstoque() {
        // Devolve o valor atual de estoque
        return estoque;
    }

    // Define uma nova quantidade em estoque
    public void setEstoque(int estoque) {
        // Garante que o estoque não seja negativo
        if (estoque < 0) {
            // Lança exceção se o estoque for inválido
            throw new IllegalArgumentException("Estoque não pode ser negativo.");
        }
        // Atualiza o campo estoque com o valor válido
        this.estoque = estoque;
    }

    // Representação textual formatada do produto
    @Override
    public String toString() {
        // Usa String.format para padronizar saída com duas casas decimais no preço
        return String.format("Produto{id=%d, nome='%s', preco=%.2f, estoque=%d}", id, nome, preco, estoque);
    }
}
