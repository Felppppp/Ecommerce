// Exceção personalizada para indicar falta de estoque
public class EstoqueInsuficienteException extends RuntimeException {

    // Construtor recebe uma mensagem e repassa para RuntimeException
    public EstoqueInsuficienteException(String mensagem) {
        super(mensagem);
    }
}
