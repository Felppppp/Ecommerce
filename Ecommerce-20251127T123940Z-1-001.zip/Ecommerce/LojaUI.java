import javax.swing.*;              // Componentes básicos de interface (JFrame, JButton, etc.)
import javax.swing.table.*;        // Classes para trabalhar com tabelas (JTable, DefaultTableModel)
import java.awt.*;                 // Layouts e fontes
import java.util.ArrayList;        // Lista de produtos

// Janela gráfica para visualizar e GERENCIAR produtos (cadastrar e repor estoque)
public class LojaUI extends JFrame {

    // Tabela que mostra os produtos na tela
    private JTable tabelaProdutos;

    // Modelo da tabela: controla linhas e colunas
    private DefaultTableModel modeloTabela;

    // Referência para a lista de produtos usada pelo sistema
    private ArrayList<Produto> produtos;

    // Construtor da janela, recebe a lista de produtos de fora (Main)
    public LojaUI(ArrayList<Produto> produtos) {
        // Guarda a lista para uso interno
        this.produtos = produtos;

        // Define o título da janela
        setTitle("Loja - Produtos cadastrados");
        // Define o tamanho inicial da janela
        setSize(650, 420);
        // Define o que acontece ao fechar (apenas fecha a janela, não mata o programa todo)
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Centraliza a janela na tela
        setLocationRelativeTo(null);

        // Cria o painel principal com um layout de bordas (NORTH, CENTER, SOUTH)
        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));
        // Adiciona uma borda invisível (margem) em volta do painel
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ======================
        //   TÍTULO NO TOPO
        // ======================
        JLabel lblTitulo = new JLabel("Produtos cadastrados");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18)); // fonte maior e em negrito
        painelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        // ======================
        //   TABELA DE PRODUTOS
        // ======================

        // Definição dos nomes das colunas da tabela
        String[] colunas = {"ID", "Nome", "Preço (R$)", "Estoque"};

        // Cria o modelo da tabela, inicialmente sem linhas (0)
        modeloTabela = new DefaultTableModel(colunas, 0) {
            // Torna todas as células não editáveis diretamente na tabela (só leitura)
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Cria a tabela usando o modelo
        tabelaProdutos = new JTable(modeloTabela);
        tabelaProdutos.setFillsViewportHeight(true); // tabela ocupa todo o espaço disponível
        tabelaProdutos.setRowHeight(24);             // altura de cada linha

        // Customiza o cabeçalho (linha das colunas)
        JTableHeader header = tabelaProdutos.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));

        // Coloca a tabela dentro de um JScrollPane para ter barra de rolagem
        JScrollPane scroll = new JScrollPane(tabelaProdutos);

        // Adiciona o scroll (com a tabela dentro) ao centro do painel
        painelPrincipal.add(scroll, BorderLayout.CENTER);

        // ======================
        //   PAINEL DE BOTÕES
        // ======================

        // Painel com layout de fluxo, alinhado à direita
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        // Botão para cadastrar novo produto
        JButton btnNovo = new JButton("Novo produto");
        // Botão para repor estoque
        JButton btnRepor = new JButton("Repor estoque");
        // Botão para recarregar a tabela (caso algo mude na lista)
        JButton btnRecarregar = new JButton("Recarregar");
        // Botão para fechar a janela
        JButton btnFechar = new JButton("Fechar");

        // Adiciona os botões ao painel
        painelBotoes.add(btnNovo);
        painelBotoes.add(btnRepor);
        painelBotoes.add(btnRecarregar);
        painelBotoes.add(btnFechar);

        // Adiciona o painel de botões na parte inferior da janela
        painelPrincipal.add(painelBotoes, BorderLayout.SOUTH);

        // Define que o conteúdo da janela será o painel principal
        setContentPane(painelPrincipal);

        // ======================
        //   AÇÕES DOS BOTÕES
        // ======================

        // Clique em "Recarregar": atualiza a tabela com a lista atual de produtos
        btnRecarregar.addActionListener(e -> atualizarTabela());

        // Clique em "Fechar": fecha a janela (dispose)
        btnFechar.addActionListener(e -> dispose());

        // Clique em "Novo produto": abre diálogos para cadastrar um novo produto
        btnNovo.addActionListener(e -> cadastrarProdutoGUI());

        // Clique em "Repor estoque": abre diálogo para aumentar o estoque do produto selecionado
        btnRepor.addActionListener(e -> reporEstoqueGUI());

        // Preenche a tabela com os produtos já existentes ao abrir a janela
        atualizarTabela();
    }

    // Atualiza a tabela com base na lista atual de produtos
    private void atualizarTabela() {
        // Limpa todas as linhas do modelo
        modeloTabela.setRowCount(0);

        // Para cada produto na lista, cria uma linha na tabela
        for (Produto p : produtos) {
            Object[] linha = {
                p.getId(),
                p.getNome(),
                String.format("%.2f", p.getPreco()), // formata o preço com 2 casas
                p.getEstoque()
            };
            modeloTabela.addRow(linha);
        }
    }

    // Cadastro de um novo produto via interface gráfica (JOptionPane)
    private void cadastrarProdutoGUI() {
        try {
            // Diálogo para ler o ID
            String idStr = JOptionPane.showInputDialog(this, "ID do produto:");
            if (idStr == null) return; // se o usuário cancelar, sai do método
            int id = Integer.parseInt(idStr.trim());

            // Diálogo para ler o nome
            String nome = JOptionPane.showInputDialog(this, "Nome do produto:");
            if (nome == null) return;

            // Diálogo para ler o preço
            String precoStr = JOptionPane.showInputDialog(this, "Preço (ex: 199.90):");
            if (precoStr == null) return;
            double preco = Double.parseDouble(precoStr.trim());

            // Diálogo para ler o estoque inicial
            String estoqueStr = JOptionPane.showInputDialog(this, "Estoque inicial:");
            if (estoqueStr == null) return;
            int estoque = Integer.parseInt(estoqueStr.trim());

            // Cria o produto (validações são feitas dentro de Produto)
            Produto novo = new Produto(id, nome, preco, estoque);

            // Adiciona na lista compartilhada com o sistema
            produtos.add(novo);

            // Atualiza a tabela para mostrar o novo produto
            atualizarTabela();

            // Mostra mensagem de sucesso
            JOptionPane.showMessageDialog(this,
                    "Produto cadastrado com sucesso!",
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            // Erro ao converter números (ID, preço, estoque)
            JOptionPane.showMessageDialog(this,
                    "Valor numérico inválido.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            // Erros de validação do domínio (ex.: nome vazio, preço negativo)
            JOptionPane.showMessageDialog(this,
                    e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Reposição de estoque via interface gráfica
    private void reporEstoqueGUI() {
        // Verifica se alguma linha foi selecionada na tabela
        int linhaSelecionada = tabelaProdutos.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um produto na tabela.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Recupera o ID do produto a partir da tabela (coluna 0)
        int idProduto = (int) modeloTabela.getValueAt(linhaSelecionada, 0);

        // Localiza o produto correspondente na lista
        Produto produtoSelecionado = null;
        for (Produto p : produtos) {
            if (p.getId() == idProduto) {
                produtoSelecionado = p;
                break;
            }
        }

        // Se por algum motivo não achar, mostra erro (não era pra acontecer normalmente)
        if (produtoSelecionado == null) {
            JOptionPane.showMessageDialog(this,
                    "Produto não encontrado na lista.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Pergunta a quantidade para repor
        String qtdStr = JOptionPane.showInputDialog(this,
                "Quantidade para repor:",
                "Reposição de estoque",
                JOptionPane.QUESTION_MESSAGE);

        // Se o usuário cancelar, sai
        if (qtdStr == null) return;

        try {
            int quantidade = Integer.parseInt(qtdStr.trim());

            // Valida quantidade positiva
            if (quantidade <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Quantidade deve ser maior que zero.",
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Calcula o novo estoque e atualiza o produto
            int novoEstoque = produtoSelecionado.getEstoque() + quantidade;
            produtoSelecionado.setEstoque(novoEstoque);

            // Atualiza a tabela para refletir a mudança
            atualizarTabela();

            // Mensagem de sucesso
            JOptionPane.showMessageDialog(this,
                    "Estoque atualizado com sucesso!",
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException e) {
            // Erro ao converter a quantidade
            JOptionPane.showMessageDialog(this,
                    "Valor numérico inválido.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            // Erros de validação (se a classe Produto tiver alguma regra)
            JOptionPane.showMessageDialog(this,
                    e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método main apenas para testar a interface isoladamente (opcional)
    public static void main(String[] args) {
        // Cria uma lista de produtos de exemplo para teste
        ArrayList<Produto> lista = new ArrayList<>();
        lista.add(new Produto(1, "Teclado Mecânico", 249.90, 5));
        lista.add(new Produto(2, "Mouse Gamer", 129.90, 10));
        lista.add(new Produto(3, "Monitor 24\"", 899.00, 3));

        // Cria e mostra a janela na thread correta do Swing
        SwingUtilities.invokeLater(() -> {
            LojaUI ui = new LojaUI(lista);
            ui.setVisible(true);
        });
    }
}
