import java.util.ArrayList; // usamos ArrayList para armazenar os itens

// Representa um pedido feito por um cliente
public class Pedido {

    // Identificador único do pedido
    private int id;

    // Cliente que fez o pedido
    private Cliente cliente;

    // Lista de itens dentro do pedido
    private ArrayList<ItemPedido> itens;

    // Status atual do pedido (ABERTO, FINALIZADO, CANCELADO)
    private PedidoStatus status;

    // Construtor: recebe um id e o cliente
    public Pedido(int id, Cliente cliente) {
        // Valida o id para garantir que é positivo
        if (id <= 0) {
            throw new IllegalArgumentException("Id do pedido deve ser positivo.");
        }

        // Valida o cliente para evitar null
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente não pode ser nulo.");
        }

        this.id = id;                       // guarda o id
        this.cliente = cliente;             // guarda o cliente
        this.itens = new ArrayList<>();     // inicializa lista vazia
        this.status = PedidoStatus.ABERTO;  // pedido começa como ABERTO
    }

    // Retorna o id do pedido
    public int getId() {
        return id;
    }

    // Retorna o cliente do pedido
    public Cliente getCliente() {
        return cliente;
    }

    // Retorna a lista de itens
    public ArrayList<ItemPedido> getItens() {
        return itens;
    }

    // Retorna o status atual do pedido
    public PedidoStatus getStatus() {
        return status;
    }

    // Altera o status do pedido
    public void setStatus(PedidoStatus status) {
        if (status == null) {
            throw new IllegalArgumentException("Status não pode ser nulo.");
        }
        this.status = status;
    }

    // Adiciona um item ao pedido com base em um produto e quantidade
    public void adicionarItem(Produto produto, int quantidade) {
        // Valida produto nulo
        if (produto == null) {
            throw new IllegalArgumentException("Produto não pode ser nulo.");
        }

        // Valida quantidade
        if (quantidade <= 0) {
            throw new IllegalArgumentException("Quantidade deve ser maior que zero.");
        }

        // Verifica se há estoque suficiente
        if (produto.getEstoque() < quantidade) {
            String msg = String.format(
                "Estoque insuficiente para o produto '%s'. Disponível: %d, solicitado: %d",
                produto.getNome(),
                produto.getEstoque(),
                quantidade
            );
            throw new EstoqueInsuficienteException(msg);
        }

        // Desconta do estoque do produto
        int estoqueRestante = produto.getEstoque() - quantidade;
        produto.setEstoque(estoqueRestante);

        // Cria um novo item de pedido usando o produto e a quantidade
        ItemPedido item = new ItemPedido(produto, quantidade);

        // Adiciona o item à lista interna do pedido
        itens.add(item);
    }

    // Calcula o total do pedido somando o subtotal de todos os itens
    public double getTotal() {
        double total = 0.0;

        // Percorre cada item do pedido e soma o subtotal
        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }

        return total;
    }

    @Override
    public String toString() {
        // Monta um resumo legível do pedido
        return String.format(
            "Pedido #%d - Cliente: %s - Itens: %d - Total: R$ %.2f - Status: %s",
            id,
            cliente.getNome(),
            itens.size(),
            getTotal(),
            status
        );
    }
}
