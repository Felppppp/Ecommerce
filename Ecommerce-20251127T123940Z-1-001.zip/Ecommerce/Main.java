import java.util.ArrayList; // Importa a classe ArrayList para listas em memória
import java.util.Scanner;   // Importa Scanner para ler entradas pelo console

// Classe principal responsável por iniciar e controlar o sistema pelo console
public class Main {

    // Scanner único para ler entradas do usuário
    private static final Scanner scanner = new Scanner(System.in);

    // Lista de produtos cadastrados na loja
    private static final ArrayList<Produto> produtos = new ArrayList<>();

    // Lista de pedidos já criados
    private static final ArrayList<Pedido> pedidos = new ArrayList<>();

    // Cliente "logado" no sistema (fixo por enquanto)
    private static final Cliente clienteAtual =
            new Cliente(1, "Maria Silva", "maria@example.com", "Rua A, 123");

    // Controla o próximo ID de pedido (auto-incremento simples)
    private static int proximoIdPedido = 1;

    // Método principal (ponto de entrada da aplicação)
    public static void main(String[] args) {
        // Adiciona um produto inicial para não começar com lista vazia
        produtos.add(new Produto(1, "Teclado Mecânico", 249.90, 5));

        // Flag que controla o loop principal do menu
        boolean executando = true;

        // Loop do menu principal
        while (executando) {
            // Exibe o menu de opções
            System.out.println("==== Menu ====");
            System.out.println("1) Listar produtos");
            System.out.println("2) Cadastrar produto");
            System.out.println("3) Repor estoque");
            System.out.println("4) Ver cliente atual");
            System.out.println("5) Criar novo pedido");
            System.out.println("6) Listar pedidos");
            System.out.println("7) Abrir interface gráfica");
            System.out.println("0) Sair");
            System.out.print("Escolha: ");

            // Lê a opção digitada e remove espaços em volta
            String opcao = scanner.nextLine().trim();

            // Decide o que fazer com base na opção escolhida
            switch (opcao) {
                case "1":
                    // Lista todos os produtos no console
                    listarProdutos();
                    break;
                case "2":
                    // Cadastra um novo produto via console
                    cadastrarProduto();
                    break;
                case "3":
                    // Reposição de estoque via console
                    reporEstoque();
                    break;
                case "4":
                    // Mostra os dados do cliente atual
                    System.out.println(clienteAtual);
                    break;
                case "5":
                    // Cria um novo pedido e adiciona itens
                    criarPedido();
                    break;
                case "6":
                    // Lista todos os pedidos já criados
                    listarPedidos();
                    break;
                case "7":
                    // Abre a interface gráfica Swing usando a mesma lista de produtos
                    abrirInterfaceGrafica();
                    break;
                case "0":
                    // Encerra o loop e finaliza o programa
                    executando = false;
                    System.out.println("Saindo...");
                    break;
                default:
                    // Tratamento para opções inválidas
                    System.out.println("Opção inválida.");
                    break;
            }

            // Linha em branco para separar uma iteração da outra
            System.out.println();
        }

        // Fecha o Scanner ao final da execução
        scanner.close();
    }

    // Lista todos os produtos atualmente cadastrados
    private static void listarProdutos() {
        // Se a lista estiver vazia, informa e sai
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        // Percorre a lista e imprime cada produto
        for (Produto produto : produtos) {
            System.out.println(produto);
        }
    }

    // Cadastra um novo produto lendo os dados pelo console
    private static void cadastrarProduto() {
        try {
            // Lê o ID do produto
            System.out.print("ID: ");
            int id = Integer.parseInt(scanner.nextLine().trim());

            // Lê o nome do produto
            System.out.print("Nome: ");
            String nome = scanner.nextLine();

            // Lê o preço do produto
            System.out.print("Preço: ");
            double preco = Double.parseDouble(scanner.nextLine().trim());

            // Lê o estoque inicial
            System.out.print("Estoque: ");
            int estoque = Integer.parseInt(scanner.nextLine().trim());

            // Cria o objeto Produto (validações são feitas dentro da classe Produto)
            Produto novoProduto = new Produto(id, nome, preco, estoque);

            // Adiciona o novo produto à lista
            produtos.add(novoProduto);

            System.out.println("Produto cadastrado com sucesso!");
        } catch (NumberFormatException e) {
            // Tratamento para entrada numérica inválida
            System.out.println("Erro: valor numérico inválido.");
        } catch (IllegalArgumentException e) {
            // Tratamento para validações de negócio (id, nome, preço, estoque)
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // Reposição de estoque lendo dados pelo console
    private static void reporEstoque() {
        try {
            // Pergunta qual produto deve ter o estoque reposto
            System.out.print("ID do produto: ");
            int id = Integer.parseInt(scanner.nextLine().trim());

            // Procura o produto pelo ID na lista
            Produto produtoEncontrado = null;
            for (Produto produto : produtos) {
                if (produto.getId() == id) {
                    produtoEncontrado = produto;
                    break; // achou, pode sair do laço
                }
            }

            // Se não encontrou, exibe mensagem e sai
            if (produtoEncontrado == null) {
                System.out.println("Produto não encontrado.");
                return;
            }

            // Lê a quantidade a ser adicionada
            System.out.print("Quantidade para repor: ");
            int quantidade = Integer.parseInt(scanner.nextLine().trim());

            // Valida quantidade positiva
            if (quantidade <= 0) {
                System.out.println("Quantidade deve ser maior que zero.");
                return;
            }

            // Calcula o novo estoque e atualiza o produto
            int novoEstoque = produtoEncontrado.getEstoque() + quantidade;
            produtoEncontrado.setEstoque(novoEstoque);

            System.out.println("Estoque atualizado com sucesso!");
        } catch (NumberFormatException e) {
            // Entrada numérica inválida
            System.out.println("Erro: valor numérico inválido.");
        } catch (IllegalArgumentException e) {
            // Erros de validação interna (ex.: estoque negativo)
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // Cria um novo pedido para o cliente atual e permite adicionar itens
    private static void criarPedido() {
        // Cria o pedido com um ID sequencial e o cliente atual
        Pedido pedido = new Pedido(proximoIdPedido++, clienteAtual);
        System.out.println("Criando Pedido #" + pedido.getId());

        // Loop para adicionar vários itens ao pedido
        while (true) {
            // Lista os produtos para ajudar o usuário a escolher
            listarProdutos();
            System.out.print("Digite o ID do produto para adicionar (ou 0 para finalizar): ");
            String entrada = scanner.nextLine().trim();

            // Se o usuário digitar 0, para de adicionar itens
            if (entrada.equals("0")) {
                break;
            }

            try {
                int idProduto = Integer.parseInt(entrada);

                // Procura o produto pelo ID
                Produto produtoEscolhido = null;
                for (Produto p : produtos) {
                    if (p.getId() == idProduto) {
                        produtoEscolhido = p;
                        break;
                    }
                }

                // Se não encontrar, informa e continua o loop
                if (produtoEscolhido == null) {
                    System.out.println("Produto não encontrado.");
                    continue;
                }

                // Lê a quantidade desejada
                System.out.print("Quantidade: ");
                int quantidade = Integer.parseInt(scanner.nextLine().trim());

                // Valida quantidade positiva
                if (quantidade <= 0) {
                    System.out.println("Quantidade deve ser maior que zero.");
                    continue;
                }

                // Tenta adicionar o item ao pedido
                // Aqui pode lançar EstoqueInsuficienteException ou IllegalArgumentException
                pedido.adicionarItem(produtoEscolhido, quantidade);

                // Se deu certo, mostra o total parcial e o estoque restante
                System.out.println("Item adicionado! Total parcial: R$ " +
                        String.format("%.2f", pedido.getTotal()));
                System.out.println("Estoque restante do produto: " + produtoEscolhido.getEstoque());

            } catch (NumberFormatException e) {
                // Usuário digitou algo que não é número
                System.out.println("Erro: valor numérico inválido.");
            } catch (EstoqueInsuficienteException e) {
                // Tratamento específico para falta de estoque
                System.out.println("Erro de estoque: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                // Outras validações de regra de negócio
                System.out.println("Erro: " + e.getMessage());
            }
        }

        // Se o pedido não tiver itens, não vale a pena salvá-lo
        if (pedido.getItens().isEmpty()) {
            System.out.println("Pedido vazio. Nada foi salvo.");
        } else {
            // Adiciona o pedido à lista de pedidos
            pedidos.add(pedido);
            System.out.println("Pedido criado com sucesso: " + pedido);
        }
    }

    // Lista todos os pedidos já criados, com seus itens
    private static void listarPedidos() {
        // Se não houver pedidos, informa e sai
        if (pedidos.isEmpty()) {
            System.out.println("Nenhum pedido criado ainda.");
            return;
        }

        System.out.println("==== Pedidos ====");
        // Percorre a lista de pedidos
        for (Pedido pedido : pedidos) {
            // Imprime o resumo do pedido (toString do Pedido)
            System.out.println(pedido);
            // Lista os itens do pedido com indentação
            for (ItemPedido item : pedido.getItens()) {
                System.out.println("   - " + item);
            }
        }
    }

    // Abre a interface gráfica Swing usando a lista de produtos atual
    private static void abrirInterfaceGrafica() {
        // Usa o método padrão do Swing para criar a UI na thread correta
        javax.swing.SwingUtilities.invokeLater(() -> {
            // Cria a janela passando a lista de produtos
            LojaUI ui = new LojaUI(produtos);
            // Torna a janela visível
            ui.setVisible(true);
        });
    }
}
