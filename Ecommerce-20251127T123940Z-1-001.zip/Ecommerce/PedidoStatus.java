// Enum que define os possíveis status de um pedido
public enum PedidoStatus {
    ABERTO,      // Pedido criado e ainda sendo montado
    FINALIZADO,  // Pedido concluído (por exemplo: pago)
    CANCELADO    // Pedido cancelado
}
