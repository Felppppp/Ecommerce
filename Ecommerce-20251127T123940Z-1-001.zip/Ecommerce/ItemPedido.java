// Representa um item dentro de um pedido (produto + quantidade)
public class ItemPedido {

    // Produto escolhido
    private Produto produto;

    // Quantidade desse produto no pedido
    private int quantidade;

    // Preço unitário no momento da compra
    private double precoUnitario;

    // Construtor: recebe o produto e a quantidade desejada
    public ItemPedido(Produto produto, int quantidade) {
        // Garante que o produto existe
        if (produto == null) {
            throw new IllegalArgumentException("Produto não pode ser nulo.");
        }

        // Garante que a quantidade é maior que zero
        if (quantidade <= 0) {
            throw new IllegalArgumentException("Quantidade deve ser maior que zero.");
        }

        // Salva o produto
        this.produto = produto;
        // Salva a quantidade
        this.quantidade = quantidade;
        // Congela o preço no momento da criação do item
        this.precoUnitario = produto.getPreco();
    }

    // Retorna o produto
    public Produto getProduto() {
        return produto;
    }

    // Retorna a quantidade
    public int getQuantidade() {
        return quantidade;
    }

    // Retorna o preço unitário armazenado
    public double getPrecoUnitario() {
        return precoUnitario;
    }

    // Calcula o subtotal: preço * quantidade
    public double getSubtotal() {
        return precoUnitario * quantidade;
    }

    @Override
    public String toString() {
        // Exemplo de saída: "Teclado Mecânico x2 - Subtotal: R$ 499,80"
        return String.format(
            "%s x%d - Subtotal: R$ %.2f",
            produto.getNome(),
            quantidade,
            getSubtotal()
        );
    }
}
